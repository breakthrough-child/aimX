import React from "react";

export default function VerticalLine() {
  return (
    <div className="w-0 h-[45px] border-l-1" style={{ borderColor: "#7CA5BE" }} />
  );
}
