import React from "react";

export default function HorizontalLine() {
  return (
    <div className="w-[316px] h-[3px] bg-black mt-2" />
  );
}
